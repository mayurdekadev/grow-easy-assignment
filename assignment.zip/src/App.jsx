import { useState } from 'react'
import Sidebar from './components/Sidebar/sidebar.component'
import './App.css'

function App() {

  return (
    <>
      <div className="mainContainer">
        <div>
          <Sidebar />
        </div>
        <div>
          Hello
        </div>
      </div>
    </>
  )
}

export default App